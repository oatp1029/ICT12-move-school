//Import statement

import java.util.Scanner; // For user input
import javax.swing.*;   // JFrame
import java.awt.*;
import java.awt.event.ActionEvent;      // JFrame Button Action
import java.awt.event.ActionListener;   // JFrame Button Action

class JFrameCalculator extends JFrame implements ActionListener {
  static Scanner scanner = new Scanner(System.in); 
 
  // Member
  private String user;
  private static String welcomeMsg = "<html><h1>Welcome <br /> Basic Calculator</h1></html>"; // Weekday
  private static String directionMsg = "<html><h3>Introduction</h3><p>Here is the <br/> that you can calculate any integers! <br/>You can add, subtract, multiply, divide,<br/> and even modulo! <br/>If you want to start,<br/> press 'go' button at the bottom. </p><h4>Enjoy!</h4></html>"; // Weekday
  private static int num1, num2, result = 0;
  private static String operator = "";
  private static boolean isOperator, isResulted = false;
  private static JLabel calsstatus = new JLabel("<html><br/><h1>Two Integer Calculation</h1><br/></html>"); // name
  
  
  // Console Constructor
  //public JFrameCalculator(String user) {
  //  this.user = user;
  // };

  public void actionPerformed(ActionEvent e)
    {
        String input = e.getActionCommand();
 
        // if the value is a number
        if ((input.charAt(0) >= '0' && input.charAt(0) <= '9')) {
            // if operand is present then add to second no
          if(isResulted){
            isResulted = false;
            num1 = 0;
            num2 = 0;
            operator = "";
            result = 0;
            isOperator = false;
          }
          
          if (!isOperator) {
              num1 *= 10;
              num1 += Integer.parseInt(input);
            // set the value of text
            calsstatus.setText("<html><br/><h1>" + Integer.toString(num1) + "</h1><br/></html>");
          } else {
              num2 *= 10;
              num2 += Integer.parseInt(input);
            // set the value of text
            calsstatus.setText("<html><br/><h1>" + Integer.toString(num1) + operator + Integer.toString(num2) + "</h1><br/></html>");
          }
        }
        else if (input.charAt(0) == 'C') {
            // clear the one letter
            num1 = 0;
            num2 = 0;
            operator = "";
            result = 0;
            isOperator = false;
            calsstatus.setText("<html><br/><h1>Two Integer Calculation</h1><br/></html>");
        }
        else if (input.charAt(0) == '=') {

          isResulted = true;
          
          // store the value in 1st
          if (operator.equals("+"))
              result = add(num1, num2);
          else if (operator.equals("-"))
              result = subtract(num1, num2);
          else if (operator.equals("/"))
              result = divide(num1, num2);
          else if (operator.equals("*"))
              result = multiply(num1, num2);
          else
              result = modulo(num1, num2);
 
            // set the value of text
            calsstatus.setText("<html><br/><h1>" + Integer.toString(num1) + operator + Integer.toString(num2) + "=" + Integer.toString(result) + "</h1><br/></html>");
 
        }
        else {
            if(isResulted){
              num1 = 0;
              num2 = 0;
              operator = "";
              result = 0;
              isOperator = false;
              calsstatus.setText("<html><br/><h1>Two Integer Calculation</h1><br/></html>");
            } else {
            // if there was no operand
              if (input.equals("") || input.equals(""))
                  num2 = 0;
              // else evaluate
              else {
                // store the value in 1st
                if (input.equals("+"))
                    operator = "+";
                else if (input.equals("-"))
                    operator = "-";
                else if (input.equals("*"))
                    operator = "*";
                else if (input.equals("/"))
                    operator = "/";
                else
                    operator = "%";
 
                // convert it to string
                isOperator = true;
              
                // set the value of text
                calsstatus.setText("<html><br/><h1>" + Integer.toString(num1) + operator + "</h1><br/></html>");
              }
            }
        }
    }
  
  // Methods = function (parameters)
  public int add(int x, int y) {
    return x + y;
  }
  
  public int subtract(int x, int y) {
    return x - y;
  }
  
  public int multiply(int x, int y) {
    return x * y;
  }
  
  public int divide(int x, int y) {
    if (y == 0) {
      System.out.println("Error! Diving by zero will get you undefined!");
      return 0;
    } else {
      return x / y;
    }
  }
  
  public int modulo(int x, int y) {
    if (y == 0) {
      System.out.println("Error! Diving by zero will get you undefined!");
      return 0;
    } else {
      return x % y;
    }
  }
  
  public static void Calculator() {
      // create btn class
      JFrameCalculator calsAction = new JFrameCalculator();
    
    
      // Window
      JFrame frame = new JFrame("Assignment 2 Basic Calculator");
      frame.setSize(330, 550);
      frame.setLayout(new BorderLayout());
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      // Panel
      JPanel welcomePanelTitle = new JPanel();
      JPanel welcomePanelDirection = new JPanel();
      JPanel welcomePanelGoBtn = new JPanel();
    
      JPanel bodyPanelDoneBtn = new JPanel();
      JPanel bodyPanelCalsResult = new JPanel();
      JPanel calculatorPanel = new JPanel(new GridLayout(5,4));
    
      JPanel thanksPanelTitle = new JPanel();
      JPanel thanksPanelText = new JPanel();
      JPanel thanksPanelCloseBtn = new JPanel();
      
      // Create Elements
      // Labels
      JLabel welcome = new JLabel(welcomeMsg); // name
      JLabel direction = new JLabel(directionMsg); // name
      JLabel thankstitle = new JLabel("<html><h1>Thank you</h1></html>");
      JLabel thankstext = new JLabel("<html><h4>for using our calculator be sure <br />to come back if you want to caculate something!</h4></html>");
      
      // Utility Buttons
      JButton goBody = new JButton("Go !");
      JButton goThanks = new JButton("Done");
      JButton exit = new JButton("Close");
      
      // Body Buttons
      JButton k0, k1, k2, k3, k4, k5, k6, k7, k8, k9, kmu, kd, kp, ks, kmo, ke, kcl, knull1, knull2, knull3;
      k0 = new JButton("0");
      k1 = new JButton("1");
      k2 = new JButton("2");
      k3 = new JButton("3");
      k4 = new JButton("4");
      k5 = new JButton("5");
      k6 = new JButton("6");
      k7 = new JButton("7");
      k8 = new JButton("8");
      k9 = new JButton("9");
      kmu = new JButton("*");
      kd = new JButton("/");
      kp = new JButton("+");
      ks = new JButton("-");
      kmo = new JButton("%");
      ke = new JButton("=");
      kcl = new JButton("C");
      knull1 = new JButton("");
      knull2 = new JButton("");
      knull3 = new JButton("");
      
      calculatorPanel.add(kcl);
      calculatorPanel.add(kmu);
      calculatorPanel.add(kd);
      calculatorPanel.add(kmo);
      calculatorPanel.add(k7);
      calculatorPanel.add(k8);
      calculatorPanel.add(k9);
      calculatorPanel.add(kp);
      calculatorPanel.add(k4);
      calculatorPanel.add(k5);
      calculatorPanel.add(k6);
      calculatorPanel.add(ks);
      calculatorPanel.add(k1);
      calculatorPanel.add(k2);
      calculatorPanel.add(k3);
      calculatorPanel.add(knull1);
      calculatorPanel.add(knull2);
      calculatorPanel.add(k0);
      calculatorPanel.add(knull3);
      calculatorPanel.add(ke);

      k0.addActionListener(calsAction);
      k1.addActionListener(calsAction);
      k2.addActionListener(calsAction);
      k3.addActionListener(calsAction);
      k4.addActionListener(calsAction);
      k5.addActionListener(calsAction);
      k6.addActionListener(calsAction);
      k7.addActionListener(calsAction);
      k8.addActionListener(calsAction);
      k9.addActionListener(calsAction);
      kmu.addActionListener(calsAction);
      kd.addActionListener(calsAction);
      kp.addActionListener(calsAction);
      ks.addActionListener(calsAction);
      kmo.addActionListener(calsAction);
      ke.addActionListener(calsAction);
      kcl.addActionListener(calsAction);
      
      
      
      // Set utility buttons actions
      goBody.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
              frame.remove(welcomePanelTitle);
              frame.remove(welcomePanelDirection);
              frame.remove(welcomePanelGoBtn);
              frame.add(bodyPanelDoneBtn, BorderLayout.SOUTH);
              frame.add(bodyPanelCalsResult, BorderLayout.NORTH);
              frame.add(calculatorPanel, BorderLayout.CENTER);
              SwingUtilities.updateComponentTreeUI(frame);
          }
      });
      
      goThanks.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
              frame.remove(bodyPanelDoneBtn);
              frame.remove(bodyPanelCalsResult);
              frame.remove(calculatorPanel);
              frame.add(thanksPanelTitle, BorderLayout.NORTH);
              frame.add(thanksPanelText, BorderLayout.CENTER);
              frame.add(thanksPanelCloseBtn, BorderLayout.SOUTH);
              SwingUtilities.updateComponentTreeUI(frame);
          }
      });
      
      exit.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
              frame.remove(thanksPanelTitle);
              frame.remove(thanksPanelText);
              frame.remove(thanksPanelCloseBtn);
              frame.setVisible(false);
          }
      });
      
      // Add Elements to Panels
      welcomePanelTitle.add(welcome);
      welcomePanelDirection.add(direction);
      welcomePanelGoBtn.add(goBody);
      bodyPanelDoneBtn.add(goThanks);
      bodyPanelCalsResult.add(calsstatus);
      thanksPanelTitle.add(thankstitle);
      thanksPanelText.add(thankstext);
      thanksPanelCloseBtn.add(exit);
      
      // Add Panels to frame
      frame.add(welcomePanelTitle, BorderLayout.NORTH);
      frame.add(welcomePanelDirection, BorderLayout.CENTER);
      frame.add(welcomePanelGoBtn, BorderLayout.SOUTH);
      
      // Set frame as visible
      frame.setVisible(true);
  }

  public void welcomeMsg(JFrameCalculator myCalculator) {    
    System.out.println("\n\n██████╗░░█████╗░░██████╗██╗░█████╗░\n██╔══██╗██╔══██╗██╔════╝██║██╔══██╗\n██████╦╝███████║╚█████╗░██║██║░░╚═╝\n██╔══██╗██╔══██║░╚═══██╗██║██║░░██╗\n██████╦╝██║░░██║██████╔╝██║╚█████╔╝\n╚═════╝░╚═╝░░╚═╝╚═════╝░╚═╝░╚════╝░\n");
    System.out.println("░█████╗░░█████╗░██╗░░░░░░█████╗░██╗░░░██╗██╗░░░░░░█████╗░████████╗░█████╗░██████╗░\n██╔══██╗██╔══██╗██║░░░░░██╔══██╗██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗\n██║░░╚═╝███████║██║░░░░░██║░░╚═╝██║░░░██║██║░░░░░███████║░░░██║░░░██║░░██║██████╔╝\n██║░░██╗██╔══██║██║░░░░░██║░░██╗██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║░░██║██╔══██╗\n╚█████╔╝██║░░██║███████╗╚█████╔╝╚██████╔╝███████╗██║░░██║░░░██║░░░╚█████╔╝██║░░██║\n░╚════╝░╚═╝░░╚═╝╚══════╝░╚════╝░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝\n");
    System.out.println("\t Welcome, " + myCalculator.user + "!\n");
    System.out.println("\t [Direction] ----------------------------\t");
    System.out.println("\t 1. Put two INTEGER type numbers \t");
    System.out.println("\t 2. Select the menu which you want to get \t");
    System.out.println("\t 3. You can get result ! \t");

  }
  
  public void menuCalculator(JFrameCalculator myCalculator) {
    int num1, num2, operator, isContinue = 1;
    num1 = 5;
    num2 = 7;
    
    while(isContinue != 0) {
      
      if(isContinue == 1){
        System.out.print("\n\n\nPut first INTEGER Number : ");
        num1 = (int) scanner.nextDouble();
        System.out.print("Put second INTEGER Number : ");
        num2 = (int) scanner.nextDouble();
        isContinue = 2;
      }

      System.out.print("\n\n[1] Add\n[2] Subtract\n[3] Multiply\n[4] Divide\n[5] Modulo\n[6] Number Reset\n[7] Exit\n\nSelect operation (ex: 1  -> add) : ");
      operator = (int) (scanner.nextDouble());
  
      switch(operator) {
        case 1:
          System.out.println("\n\nAdd " + num1 + " + " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.add(num1, num2));
          break;
        case 2:
          System.out.println("\n\nAdd " + num1 + " - " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.subtract(num1, num2));
          break;
        case 3:
          System.out.println("\n\nAdd " + num1 + " * " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.multiply(num1, num2));
          break;
        case 4:
          System.out.println("\n\nAdd " + num1 + " / " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.divide(num1, num2));
          break;
        case 5:
          System.out.println("\n\nAdd " + num1 + " % " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.modulo(num1, num2));
          break;
        case 6:
          isContinue = 1;
          break; 
        case 7:
          isContinue = 0;
      }

      if (isContinue == 2) {
        System.out.print("\n\n Do you want to RESET Numbers? \n\n[1] Yes, I want to reset numbers\n[any number] No, I want to continue with same numbers");
        int reset = (int) scanner.nextDouble();
        if (reset == 1) {
          isContinue = 1;
        } else {
          isContinue = 2;
        }
      }
    } 
  }

  public void thanksMsg(JFrameCalculator myCalculator) {
    System.out.println("\nThank you " + myCalculator.user + " for using our calculator be sure to come back if you want to caculate something!\n\n");
  }
  
  public static void main (String[] args) {
    
    Calculator();
      
    // System.out.print("\t Hello, What is your name? : ");
    // String username = scanner.next();
    // JFrameCalculator myCalculator = new JFrameCalculator(username);

    // // Welcome
    // myCalculator.welcomeMsg(myCalculator);
    
    // // UX
    // myCalculator.menuCalculrator(myCalculator);

    // // Thanks
    // myCalculator.thanksMsg(myCalculator);
    
  }
}


