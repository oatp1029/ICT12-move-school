//Import statement
import java.util.Scanner; // For user input
import java.util.InputMismatchException;


/**
 * Title: A Basic Calculator 
 * 
 * 
 * Program Summary: This is a basic calculator that can add, subtract, multiply, divide, and modulo. People can follow the intructions and use the calculator to solve their equations. 
 * 
 * 
 * Program Element List: try, catch, continue, Expection, nextInt, private, this, switch, case, continue   
 *
 * @author Will & Alana
 * @version 10/12/2023
 */

public class Calculator {

  //Global Static Varibales
  static Scanner scanner = new Scanner(System.in); //calling scanner

  // Instance Variable
  private String user; // User's name
  
  
  
  // Constructor
  public Calculator(String user) {
    this.user = user;
  } // End of constructor Calculator

  
  
  
  
  /**
   * Summary: This method will add the user inputs.
   * Parameter(s): int x, int y. 
   * Return(s): x + y.
   */
  public int add(int x, int y) {
    return x + y; // userinput adds
  } // End of method add



  
  
  /**
   * Summary: This method will subtract the user inputs.
   * Parameter(s): int x, int y. 
   * Return(s): x - y.
   */
  public int subtract(int x, int y) {
    return x - y; // userinput subtracts
  } // End of method subtract



  
  
  /**
   * Summary: This method will multiply the user inputs.
   * Parameter(s): int x, int y. 
   * Return(s): x * y.
   */
  public int multiply(int x, int y) {
    return x * y; // userinput multiplies
  } // End of method multiply



  
  
  /**
   * Summary: This method will divide user inputs, and remain the error when user put 0.
   * Parameter(s): int x, int y. 
   * Return(s): 0, x / y.
   */
  public int divide(int x, int y) {
    if (y == 0) {
      System.out.println("Error! Diving by zero will get you undefined!");
      return 0;
    } else {
      return x / y; // if user put number other than 0 it will divide 
    }
  } // End of method divide 



  
  
  /**
   * Summary: This method will get a modulo the two userinputs and remind the error when user put 0.
   * Parameter(s): int x, int y. 
   * Return(s): 0, x % y.
   */
  public int modulo(int x, int y) {
    if (y == 0) {
      System.out.println("Error! Diving by zero will get you undefined!"); // when user put 0
      return 0;
    } else {
      return x % y;
    }
  } // End of method modulo



  
  
  /**
   * Summary: This method will welcome the user, introduction, and instruction how to use this program.
   * Parameter(s): Calculator myCalculator. 
   * Return(s): void.
   */
  public void welcomeMsg(Calculator myCalculator) {    
    System.out.println("\n\n██████╗░░█████╗░░██████╗██╗░█████╗░\n██╔══██╗██╔══██╗██╔════╝██║██╔══██╗\n██████╦╝███████║╚█████╗░██║██║░░╚═╝\n██╔══██╗██╔══██║░╚═══██╗██║██║░░██╗\n██████╦╝██║░░██║██████╔╝██║╚█████╔╝\n╚═════╝░╚═╝░░╚═╝╚═════╝░╚═╝░╚════╝░\n");
    System.out.println("░█████╗░░█████╗░██╗░░░░░░█████╗░██╗░░░██╗██╗░░░░░░█████╗░████████╗░█████╗░██████╗░\n██╔══██╗██╔══██╗██║░░░░░██╔══██╗██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗\n██║░░╚═╝███████║██║░░░░░██║░░╚═╝██║░░░██║██║░░░░░███████║░░░██║░░░██║░░██║██████╔╝\n██║░░██╗██╔══██║██║░░░░░██║░░██╗██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║░░██║██╔══██╗\n╚█████╔╝██║░░██║███████╗╚█████╔╝╚██████╔╝███████╗██║░░██║░░░██║░░░╚█████╔╝██║░░██║\n░╚════╝░╚═╝░░╚═╝╚══════╝░╚════╝░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝\n");
    System.out.println("\t Welcome, " + myCalculator.user + "!\n");
    System.out.println("\t [Introduction] -------------------------\t"); // Intro
    System.out.println("\t It can give result of two numbers being added, subtracted, multiplied, divided,");
    System.out.println("\t and give the remainder to two numbers being divided.");
    System.out.println();
    System.out.println("\t This program allows basic calculation of two integers.\t");
    System.out.println("\t [Direction] ----------------------------\t");
    System.out.println("\t 1. Put two INTEGER type numbers \t");
    System.out.println("\t 2. Select the menu which you want to get \t");
    System.out.println("\t 3. You can get result ! \t");
  } // End of method welcomeMsg


  
  

  /**
   * Summary: This method declare members, catch the invalid value, button that people can choose the operator, display the result, and reset.
   * Parameter(s): Calculator myCalculator
   * Return(s): void.
   */
  public void menuCalculator(Calculator myCalculator) {
    
    // Member declaration 
    int num1, num2, operator, isContinue = 1; //userInput
    num1 = 0;
    num2 = 0;
    
    
    
    while(isContinue != 0) {
      if (isContinue == 1) {
        while(true) { //Ensure the user input for first integer is valid
          try { //If the user input is not an integer, it will throw an exception.
            System.out.print("\n\n\nPut first INTEGER Number : ");
            num1 = scanner.nextInt();
            System.out.print("You entered: " + num1);
            break;
            
          } catch (Exception e) {
            System.out.println("That's not an integer, please try again.");
            scanner.next();
          } // End of try catch statement
        } //End of while loop

        while(true) { //Ensure the user input for second integer is valid
          try {
            System.out.print("\n\nPut second INTEGER Number : ");
            num2 = scanner.nextInt();
            System.out.print("You entered: " + num2);
            isContinue = 2;
            break;
            
          } catch (Exception e) {
            System.out.println("That's not an integer, please try again.");
            scanner.next(); //Enable user to input again
            continue;
          } //End of try catch statement
        } //End of while loop
      } //End of if statement

      System.out.print("\n\n[1] Add\n[2] Subtract\n[3] Multiply\n[4] Divide\n[5] Modulo\n[6] Number Reset\n[7] Exit\n\n");
      
      while(true) { //Ensure the user input for operator is valid
        try { //If the user input is not an integer, it will throw an exception.
          System.out.print("\nSelect operation (ex: 1  -> add) : ");
          operator = (int) (scanner.nextInt());
          break;
          
        } catch (Exception e) {
          System.out.println("That's not an operator, please try again.");
          scanner.next();
          continue;
        } //End of try catch statment
      } //End of while loop

      if (operator > 7 || operator <= 0) { //If user entured a number beyond provided choice, it will ask them to retry
        System.out.println("That's not an operator, please try again.");
        continue;
      
      } //End of if statement

      switch(operator) { // This will display the calculation of each operator, number reset, and exit
        case 1:
          System.out.println("\n\nAdd " + num1 + " + " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.add(num1, num2));
          break;
        case 2:
          System.out.println("\n\nSubtract " + num1 + " - " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.subtract(num1, num2));
          break;
        case 3:
          System.out.println("\n\nMultiply " + num1 + " * " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.multiply(num1, num2));
          break;
        case 4:
          System.out.println("\n\nDivide " + num1 + " / " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.divide(num1, num2));
          break;
        case 5:
          System.out.println("\n\nModulo " + num1 + " % " + num2 + " is : ");
          System.out.println("[Answer] : " + myCalculator.modulo(num1, num2));
          break;
        case 6:
          isContinue = 1; // number rest
          break; 
        case 7:
          isContinue = 0; // exit
      } //End of switch
      
      if (isContinue == 2) {
        while (true) {
          String reset;
          
          while (true) {
            try { //Ask user if they want to reset the number for the second calculation
              System.out.print("\n\n Do you want to RESET Numbers? (y/n): ");
              reset = scanner.next();
              break;
              
            } catch (Exception e) {
              System.out.println("Invalid input");
              continue;
            } //End of try catch statement
          } //End of while loop
          
          if (reset.equals("y")) { //If user input is "y", it will reset the numbers
            isContinue = 1;
            break;
            
          } else if (reset.equals("n")) { //If user input is "n", it will break the loop
            isContinue = 2;
            break;
            
          } else { //Inputs other than "y" and "n" will be asked to retry
            System.out.println("Invalid input");
            continue;
          } // End of if/else statment
        } // End of while loop
      } // End of if statement 
    } // End of while loop
  } // End of menuCalculator method




  
  /**
   * Summary: This method will put out the thank you message.
   * Parameter(s): Calculator myCalculator. 
   * Return(s): void.
   */
  public void thanksMsg(Calculator myCalculator) {
    System.out.println("\nThank you " + myCalculator.user + " for using our calculator be sure to come back if you want to caculate something!\n\n");
  } // End of method thanksMsg




  
  /**
   * Summary: This method is a program manager, calling functions, and clear the console.
   * Parameter(s): String[] args. 
   * Return(s): void.
   */
  public static void main (String[] args) {
      
    JFrameCalculator runGui = new JFrameCalculator(); // open both scanner and jframe
    
    System.out.println("\f"); //clears the terminal
    System.out.flush(); //clears the scanner

    System.out.print("\t Hello, What is your name? : ");
    String username = scanner.next();
    Calculator myCalculator = new Calculator(username);

    // Welcome
    myCalculator.welcomeMsg(myCalculator);
    
    // UX
    myCalculator.menuCalculator(myCalculator);

    // Thanks
    scanner.close();
    myCalculator.thanksMsg(myCalculator);
    
  } // End of main
} // End of class Calculator





/*
 * Notes:
 * In main, less code literally a program manager 
 * We need to make sure that the user put the right input (String instead int)
 * We are using Try and Catch method 
 * We found a bug for switch the operator.
 *
 *
 *
 *
 *
 * Test Code: 
 * System.out.print("Put second INTEGER Number : ");
 * num2 = (int) scanner.nextDouble();
 * isContinue = 2;
 * 
 * 
 * 
 * 
 * 
*/


