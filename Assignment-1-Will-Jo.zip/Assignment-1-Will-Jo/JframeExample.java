import javax.swing.*; //JFrame
import java.awt.*; //JPanel

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class JframeExample
{
    public static void main(String[] args) {
        //Window 
        JFrame frame = new JFrame("JFrame Ttile"); 
        frame.setSize(400, 200); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // close the window 
        
        //Panel
        JPanel examplePanel = new JPanel();
        examplePanel.setLayout(new FlowLayout());
        
        // Create Elements 
        JButton button = new JButton("Button 1");
        JLabel label = new JLabel("Label"); 
        JTextField textField = new JTextField(10); 
        
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String changed = textField.getText();
                label.setText(changed);
                button.setText("Done");
            }
        });
        
        // Positioning
        examplePanel.add(button); 
        examplePanel.add(label); 
        examplePanel.add(textField); 
        
        frame.add(examplePanel);
        
        
        // Rendering
        frame.setVisible(true); 
        
    }
}
