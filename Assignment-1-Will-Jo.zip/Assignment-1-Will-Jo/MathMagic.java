
/**
 * Write a description of class MathMagic here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner; // For user input

public class MathMagic
{
    static Scanner scanner = new Scanner(System.in); 
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public static void main(String[] args) {
        // Original Number Declearation: 
        System.out.println("[Math Magic !]");
        System.out.print("Please Input an Integer : ");

        int myNumber = scanner.nextInt();
        
        System.out.println("Original Number : " + myNumber);
        
        int stepOne = myNumber * myNumber;
        System.out.println("[Step One] \nOriginal Number Multiply by it self");
        System.out.println("After Step One : " + stepOne);
        
        int stepTwo = stepOne + myNumber;
        System.out.println("[Step Two] \nPlus Original Number to Result of Step One");
        System.out.println("After Step Two : " + stepTwo);
        
        int stepThree = stepTwo / myNumber; 
        System.out.println("[Step Three] \nDivide result of Step Two by Original number");
        System.out.println("After Step Three : " + stepThree);
        
        int stepFour = stepThree + 17; 
        System.out.println("[Step Four] \nPlus 17 to result of Step One");
        System.out.println("After Step Four : " + stepFour);
        
        int stepFive = stepFour - myNumber;
        System.out.println("[Step Five] \nResult of Step Four Minus Original Number");
        System.out.println("After Step Five : " + stepFive);
        
        int stepSix = stepFive / 6;
        System.out.println("[Step Six] \nResult of Divide Result of Step Five by 6");
        System.out.println("After Step six : " + stepSix);
        
        System.out.println("[Final Result]");
        System.out.println(stepSix + " is always 3!");
    } // End of main

    /**
     * Constructor for objects of class MathMagic
     */

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */

} // End of class MathMagic


/* Test Code:
 * System.out.println("Original Number : " + mynumber);
 */