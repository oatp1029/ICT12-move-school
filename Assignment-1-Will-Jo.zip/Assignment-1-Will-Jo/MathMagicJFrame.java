/**
 * Write a description of class MathMagic here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
// import java.util.Scanner; // For user input

import javax.swing.*; //JFrame
import java.awt.*; 
import java.awt.event.ActionEvent; // JFrame Button Action
import java.awt.event.ActionListener; // JFrame Button Action

public class MathMagicJFrame
{   
    static int myNumber = 0;
    static int stepOne = 0;
    static int stepTwo = 0;
    static int stepThree = 0; 
    static int stepFour = 0;
    static int stepFive = 0;
    static int stepSix = 0;
    
    // JFrame
    public static void JFrameMathMagic() {
        //Window 
        JFrame frame = new JFrame("Assignment1 MathMagic JFrame"); 
        frame.setSize(400, 550); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // close the window 
        
        //Panel
        JPanel bodyPanel = new JPanel();
        
        // Create Elements 
        //title 
        JLabel title = new JLabel("<html><h1>Welcome :)</h1><h2>[Math Magic]</h2><p>This program will show amazing magic<br>to you that if you put any number<br>the result will always be the same! Ready to get surprised?</p><h3><br>[Direction]</h3><p>1. Put an integer number at text field</p><p>2. Click 'Go !' button</p><p>3. Check final results are always same</p><br><br><br></html>"); 
        
        // header 
        JLabel request = new JLabel("Please Input an Integer and Click");
        JTextField myNumberGet = new JTextField(3); 
        JButton button = new JButton("Go !"); 
        
        

        
        // Body 
        JLabel resultLabel = new JLabel("", SwingConstants.CENTER); // For use HTML
        
        
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                String myNumberString = myNumberGet.getText(); // Get Input and convert String to Interger
                myNumber = Integer.parseInt(myNumberString);
                
                ConsoleMathMagic(myNumber);
                
                stepOne = myNumber * myNumber;
                stepTwo = stepOne + myNumber;
                stepThree = stepTwo / myNumber; 
                stepFour = stepThree + 17;
                stepFive = stepFour - myNumber;
                stepSix = stepFive / 6;
                
                String result = "<html><h3>Result</h3><p>[Step One] \nOriginal Number Multiply by it self</p><p>After Step One : " + stepOne + "</p><br><p>[Step Two] \nPlus Original Number to Result of Step One</p><p>After Step Two : " + stepTwo + "</p><br><p>[Step Three] \nDivide Result of Step Two by Original Number</p><p>After Step Three : " + stepThree + "</p><br><p>[Step Four] \nPlus 17 to Result of Step One</p><p>After Step Four : " + stepFour + "</p><br><p>[Step Five] \nResult of Step Four Minus Original Number</p><p>After Step Five : " + stepFive + "</p><br><p>[Step Six] \nResult of Divide Result of Step Five by 6</p><p>After Step Six : " + stepSix + "</p><br><p>[Final Result]</p><p>" +stepSix + " is always 3!</p><br><h2>Thank You !</h2></html>";
 
                title.setText("");
                resultLabel.setText(result);
            }
        });
        
        
        // JLabel stepOneResultLabel = new JLabel("After Step One : " + stepOne);
        
        // JLabel stepTwoLabel = new JLabel("[Step Two] Plus Original Number to Result of Step One");
        // JLabel stepTwoResultLabel = new JLabel("After Step Two : " + stepTwo);
        
        // JLabel stepThreeLabel = new JLabel("[Step Three] Divide result of Step Two by Original number");
        // JLabel stepThreeResultLabel = new JLabel("After Step Three : " + stepThree);
        
        // JLabel stepFourLabel = new JLabel("[Step Four] Plus 17 to result of Step One");
        // JLabel stepFourResultLabel = new JLabel("After Step Four : " + stepFour);
        
        // JLabel stepFiveLabel = new JLabel("[Step Five] Result of Step Four Minus Original Number");
        // JLabel stepFiveResultLabel = new JLabel("After Step Five : " + stepFive);
        
        // JLabel stepSixLabel = new JLabel("[Step Six] Result of Divide Result of Step Five by 6");
        // JLabel stepSixResultLabel = new JLabel("After Step six : " + stepSix);
        
        
        
        // Positioning
        bodyPanel.add(title); 
        bodyPanel.add(request); 
        bodyPanel.add(myNumberGet);
        bodyPanel.add(button); 
        bodyPanel.add(resultLabel); 
        
        frame.getContentPane().add(bodyPanel);

    
        
        // Rendering
        frame.setVisible(true); 
    }
    
    //If JFrame doesn't exist please use Scanner
    // static Scanner scanner = new Scanner(System.in);
    
    //console 
    public static void ConsoleMathMagic(int myNumber) {
        myNumber = myNumber; 
        
        System.out.println("[Math Magic - Console]");
        
        System.out.println("Original Number : " + myNumber);
        
        int stepOne = myNumber * myNumber;
        System.out.println("[Step One] \nOriginal Number Multiply by it self");
        System.out.println("After Step One : " + stepOne);
        
        int stepTwo = stepOne + myNumber;
        System.out.println("[Step Two] \nPlus Original Number to Result of Step One");
        System.out.println("After Step Two : " + stepTwo);
        
        int stepThree = stepTwo / myNumber; 
        System.out.println("[Step Three] \nDivide result of Step Two by Original number");
        System.out.println("After Step Three : " + stepThree);
        
        int stepFour = stepThree + 17; 
        System.out.println("[Step Four] \nPlus 17 to result of Step One");
        System.out.println("After Step Four : " + stepFour);
        
        int stepFive = stepFour - myNumber;
        System.out.println("[Step Five] \nResult of Step Four Minus Original Number");
        System.out.println("After Step Five : " + stepFive);
        
        int stepSix = stepFive / 6;
        System.out.println("[Step Six] \nResult of Divide Result of Step Five by 6");
        System.out.println("After Step six : " + stepSix);
        
        System.out.println("[Final Result]");
        System.out.println(stepSix + " is always 3!");
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public static void main(String[] args) {
        System.out.println("[Math Magic !]");
        
        JFrameMathMagic();
        
        // System.out.print("Please Input an Integer : ");
        //int myNumber = scanner.nextInt();
        
    } // End of main

    /**
     * Constructor for objects of class MathMagic
     */

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */

} // End of class MathMagic


/* Test Code:
 * System.out.println("Original Number : " + mynumber);
 */